import React from 'react';

const LocaleContext = React.createContext();

export default LocaleContext;
