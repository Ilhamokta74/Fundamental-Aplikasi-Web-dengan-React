import React from 'react';
import NotFoundMessage from '../components/NotFoundMessage';

const ErrorPage = () => (
    <NotFoundMessage />
);

export default ErrorPage;
